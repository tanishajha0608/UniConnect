import type React from "react"
import { notFound } from "next/navigation"
import { MainNav } from "@/components/main-nav"
import { UserNav } from "@/components/user-nav"

interface UniversityLayoutProps {
  params: { university: string }
  children: React.ReactNode
}

async function getUniversity(slug: string) {
  try {
    // A relative URL works in every environment ‒ dev, preview, and production
    const response = await fetch(`/api/universities/${slug}`, {
      cache: "force-cache",
      next: { revalidate: 3600 }, // Revalidate every hour
    })

    if (!response.ok) return null
    return await response.json()
  } catch (error) {
    console.error("Error fetching university:", error)
    return null
  }
}

export default async function UniversityLayout({ params, children }: UniversityLayoutProps) {
  const university = await getUniversity(params.university)

  if (!university) {
    notFound()
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background">
        <div className="container flex h-16 items-center">
          <MainNav university={university} />
          <div className="ml-auto flex items-center space-x-4">
            <UserNav />
          </div>
        </div>
      </header>
      <main className="flex-1">{children}</main>
    </div>
  )
}
